// Входные данные от вершинного шейдера
varying vec3 v_worldPos; // Позиция пикселя в мире
uniform vec3 u_sunDirection; // Направление на солнце (передается игрой)

void main() {
    // 1. Нормализуем направление взгляда на этот конкретный пиксель неба
    vec3 viewDir = normalize(v_worldPos);

    // 2. Задаем цвета для реалистичной атмосферы (Зенит, Горизонт, Дымка)
    vec3 skyZenith = vec3(0.15, 0.35, 0.75);   // Глубокий синий вверху
    vec3 skyHorizon = vec3(0.55, 0.75, 0.95);  // Светло-голубой у земли
    vec3 sunColor = vec3(1.0, 0.85, 0.65);     // Цвет свечения солнца

    // 3. Расчет градиента высоты (зависит от координаты Y)
    float height = max(viewDir.y, 0.0);
    // Плавно смешиваем горизонт и зенит
    vec3 skyColor = mix(skyHorizon, skyZenith, pow(height, 0.5));

    // 4. Добавляем реалистичное солнечное рассеяние (свечение вокруг солнца)
    // Считаем угол между взглядом игрока и солнцем
    float sunGlow = max(dot(viewDir, normalize(u_sunDirection)), 0.0);
    
    // Математическая модель Ми (Mie scattering) для создания мягкого ореола
    float halo = pow(sunGlow, 120.0) * 1.5;     // Жесткий диск солнца
    float atmosphere = pow(sunGlow, 8.0) * 0.4; // Мягкое свечение вокруг

    // 5. Финальное объединение цветов
    vec3 finalSky = skyColor + (sunColor * (halo + atmosphere));

    // Выводим результат на экран
    gl_FragColor = vec4(finalSky, 1.0);
}
